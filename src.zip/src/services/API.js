// src/services/APIs.js
import axios from 'axios';

// === GANTI URL INI SAMA URL MOCKAPI ABANG & SESUAIKAN RESOURCE NAME ===
const MOCKAPI_BASE_URL = 'https://683d7a54199a0039e9e5a10c.mockapi.io/api'; // GANTI xxxxxxxx
const RECIPES_ENDPOINT = `${MOCKAPI_BASE_URL}/Resep`; // <-- GANTI JADI /Resep (sesuai nama resource Abang)

// Fungsi buat ngambil semua resep
export const getAllRecipes = async () => {
  try {
    const response = await axios.get(RECIPES_ENDPOINT);
    // Map field dari MockAPI ke format yang dipake aplikasi
    return response.data.map(recipeFromApi => ({
      id: recipeFromApi.id,
      name: recipeFromApi.NamaResep, // <-- SESUAIKAN
      image: recipeFromApi.Foto ? { uri: recipeFromApi.Foto } : null, // <-- SESUAIKAN field Foto
      shortDescription: recipeFromApi.DeskripsiSingkat, // <-- SESUAIKAN
      ingredients: Array.isArray(recipeFromApi.BahanBahan) ? recipeFromApi.BahanBahan : [], // <-- SESUAIKAN
      steps: Array.isArray(recipeFromApi.Langkah) ? recipeFromApi.Langkah : [], // <-- SESUAIKAN
      createdAt: recipeFromApi.createdAt,
      // Tambahin field lain kalo ada
    }));
  } catch (error) {
    console.error("Error pas ngambil semua resep:", error);
    throw error;
  }
};

// Fungsi buat ngambil satu resep berdasarkan ID
export const getRecipeById = async (recipeId) => {
  try {
    const response = await axios.get(`${RECIPES_ENDPOINT}/${recipeId}`);
    const recipeFromApi = response.data;
    return {
      id: recipeFromApi.id,
      name: recipeFromApi.NamaResep, // <-- SESUAIKAN
      image: recipeFromApi.Foto ? { uri: recipeFromApi.Foto } : null, // <-- SESUAIKAN
      shortDescription: recipeFromApi.DeskripsiSingkat, // <-- SESUAIKAN
      ingredients: Array.isArray(recipeFromApi.BahanBahan) ? recipeFromApi.BahanBahan : [], // <-- SESUAIKAN
      steps: Array.isArray(recipeFromApi.Langkah) ? recipeFromApi.Langkah : [], // <-- SESUAIKAN
      createdAt: recipeFromApi.createdAt,
    };
  } catch (error) {
    console.error(`Error pas ngambil resep dengan ID ${recipeId}:`, error);
    throw error;
  }
};

// Fungsi buat nambah resep baru (POST)
export const addNewRecipeAPI = async (recipeDataFromApp) => { // recipeDataFromApp pake field 'name', 'shortDescription', dll.
  try {
    // Ubah field dari aplikasi ke format MockAPI
    const payloadToApi = {
      NamaResep: recipeDataFromApp.name, // <-- SESUAIKAN
      Foto: typeof recipeDataFromApp.image === 'string' ? recipeDataFromApp.image : (recipeDataFromApp.image?.uri || "https://via.placeholder.com/300/CCCCCC/FFFFFF?text=ResepBaru"), // <-- SESUAIKAN, kirim URL string
      DeskripsiSingkat: recipeDataFromApp.shortDescription, // <-- SESUAIKAN
      BahanBahan: recipeDataFromApp.ingredients, // <-- SESUAIKAN
      Langkah: recipeDataFromApp.steps, // <-- SESUAIKAN
      createdAt: new Date().toISOString(), // MockAPI biasanya handle ini, tapi bisa juga dikirim
      // Field lain yang mungkin ada di schema MockAPI Abang
    };

    const response = await axios.post(RECIPES_ENDPOINT, payloadToApi);
    return response.data; // Balikin data dari API (yang udah pake field MockAPI)
  } catch (error) {
    console.error("Error pas nambah resep baru:", error);
    throw error;
  }
};

// Fungsi buat update resep (PUT) - SESUAIKAN FIELD JUGA
export const updateRecipeAPI = async (recipeId, recipeDataFromApp) => {
  try {
    const payloadToApi = {
      NamaResep: recipeDataFromApp.name,
      Foto: typeof recipeDataFromApp.image === 'string' ? recipeDataFromApp.image : (recipeDataFromApp.image?.uri || "https://via.placeholder.com/300/CCCCCC/FFFFFF?text=UpdateResep"),
      DeskripsiSingkat: recipeDataFromApp.shortDescription,
      BahanBahan: recipeDataFromApp.ingredients,
      Langkah: recipeDataFromApp.steps,
      // Jangan kirim 'id' atau 'createdAt' di payload PUT biasanya, kecuali API-nya minta
    };
    const response = await axios.put(`${RECIPES_ENDPOINT}/${recipeId}`, payloadToApi);
    return response.data;
  } catch (error) {
    console.error(`Error pas update resep dengan ID ${recipeId}:`, error);
    throw error;
  }
};

// Fungsi buat hapus resep (DELETE) - Gak perlu mapping field
export const deleteRecipeAPI = async (recipeId) => {
  try {
    const response = await axios.delete(`${RECIPES_ENDPOINT}/${recipeId}`);
    return response.data;
  } catch (error) {
    console.error(`Error pas hapus resep dengan ID ${recipeId}:`, error);
    throw error;
  }
};
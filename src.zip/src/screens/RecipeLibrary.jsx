// src/screens/RecipeLibrary.jsx
import React, { useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Image,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useFocusEffect } from '@react-navigation/native';
import { getAllRecipes } from '../services/API';

const screenWidth = Dimensions.get('window').width;

const RecipeLibrary = ({ navigation }) => {
  const [recipes, setRecipes] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Fungsi untuk mengambil data resep dari API
  const fetchRecipes = async () => {
    try {
      const data = await getAllRecipes();
      setRecipes(data);
    } catch (error) {
      console.error('Gagal mengambil data resep:', error);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  // Mengambil data saat layar difokuskan
  useFocusEffect(
    useCallback(() => {
      setIsLoading(true);
      fetchRecipes();
    }, [])
  );

  // Fungsi untuk menangani pull-to-refresh
  const onRefresh = () => {
    setIsRefreshing(true);
    fetchRecipes();
  };

  // Fungsi untuk menangani navigasi ke detail resep
  const handleRecipePress = (recipeId) => {
    navigation.navigate('RecipeDetail', { recipeId });
  };

  // Menampilkan indikator loading saat data pertama kali dimuat
  if (isLoading && recipes.length === 0) {
    return (
      <View style={[styles.outerContainer, styles.loadingContainer]}>
        <ActivityIndicator size="large" color="#f57c00" />
        <Text>Memuat koleksi resep...</Text>
      </View>
    );
  }

  // Fungsi untuk merender setiap item resep
  const renderRecipeItem = ({ item }) => (
    <TouchableOpacity
      key={item.id}
      style={styles.recipeItem}
      onPress={() => handleRecipePress(item.id)}
    >
      <Image
        source={item.image || { uri: 'https://via.placeholder.com/300/CCCCCC/FFFFFF?text=No+Image' }}
        style={styles.recipeImage}
      />
      <View style={styles.recipeTextContainer}>
        <Text style={styles.recipeName}>{item.name}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.outerContainer}>
      <Text style={styles.headerTitle}>Koleksi Resep WenakCook</Text>
      <FlatList
        data={recipes}
        keyExtractor={(item) => item.id.toString()}
        renderItem={renderRecipeItem}
        contentContainerStyle={styles.container}
        refreshControl={
          <RefreshControl refreshing={isRefreshing} onRefresh={onRefresh} colors={['#f57c00']} />
        }
        ListEmptyComponent={
          <Text style={styles.noItemsText}>
            {isLoading ? 'Memuat...' : 'Belum ada resep di koleksi.'}
          </Text>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  outerContainer: {
    flex: 1,
    backgroundColor: '#f8f8f8',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    paddingVertical: 15,
    backgroundColor: '#fff',
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  container: {
    paddingHorizontal: 10,
    paddingTop: 10,
    paddingBottom: 20,
    alignItems: 'center',
  },
  recipeItem: {
    width: screenWidth * 0.9,
    backgroundColor: '#fff',
    borderRadius: 12,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.1,
    shadowRadius: 3.84,
    elevation: 3,
    overflow: 'hidden',
  },
  recipeImage: {
    width: '100%',
    height: 180,
    resizeMode: 'cover',
    backgroundColor: '#e0e0e0',
  },
  recipeTextContainer: {
    padding: 12,
  },
  recipeName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  noItemsText: {
    fontSize: 16,
    color: '#999',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 50,
  },
});

export default RecipeLibrary;

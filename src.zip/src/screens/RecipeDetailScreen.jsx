import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Alert,
} from 'react-native';
import { launchImageLibrary } from 'react-native-image-picker';

const RecipeDetailScreen = ({ navigation }) => {
  const [name, setName] = useState('');
  const [shortDescription, setShortDescription] = useState('');
  const [ingredients, setIngredients] = useState(['']);
  const [steps, setSteps] = useState(['']);
  const [imageUri, setImageUri] = useState(null);
  const [uploading, setUploading] = useState(false);

  const pickImage = async () => {
    const permissionResult = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!permissionResult.granted) {
      Alert.alert('Izin Ditolak', 'Izin akses galeri dibutuhkan!');
      return;
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      quality: 0.7,
      allowsEditing: true,
    });

    if (!result.cancelled) {
      setImageUri(result.assets?.[0]?.uri || result.uri);
    }
  };

  const handleAddIngredient = () => {
    setIngredients([...ingredients, '']);
  };

  const handleAddStep = () => {
    setSteps([...steps, '']);
  };

  const handleSubmit = async () => {
    if (!name || !shortDescription || ingredients.length === 0 || steps.length === 0) {
      Alert.alert('Peringatan', 'Semua field harus diisi!');
      return;
    }

    setUploading(true);

    let imageUrl = null;
    if (imageUri) {
      const filename = imageUri.split('/').pop();
      const match = /\.(\w+)$/.exec(filename || '');
      const type = match ? `image/${match[1]}` : `image`;

      const formData = new FormData();
      formData.append('file', {
        uri: imageUri,
        name: filename,
        type,
      });

      try {
        const res = await fetch('https://your-api.com/upload', {
          method: 'POST',
          body: formData,
          headers: {
            'Content-Type': 'multipart/form-data',
          },
        });

        const json = await res.json();
        imageUrl = json.url; // misal: 'https://your-api.com/uploads/nasigoreng.jpg'
      } catch (err) {
        Alert.alert('Gagal Upload', 'Gagal mengunggah gambar!');
        setUploading(false);
        return;
      }
    }

    try {
      const response = await fetch('https://your-api.com/recipes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          shortDescription,
          ingredients: ingredients.filter(i => i.trim() !== ''),
          steps: steps.filter(s => s.trim() !== ''),
          image: imageUrl,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        Alert.alert('Sukses', 'Resep berhasil ditambahkan!');
        navigation.navigate('RecipeDetail', { recipe: data });
      } else {
        Alert.alert('Gagal', data.message || 'Gagal menambahkan resep!');
      }
    } catch (error) {
      Alert.alert('Error', 'Terjadi kesalahan saat menambahkan resep.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.title}>Tambah Resep</Text>

      <TextInput
        placeholder="Nama Resep"
        style={styles.input}
        value={name}
        onChangeText={setName}
      />

      <TextInput
        placeholder="Deskripsi Singkat"
        style={styles.input}
        value={shortDescription}
        onChangeText={setShortDescription}
      />

      <Text style={styles.sectionTitle}>Bahan-bahan</Text>
      {ingredients.map((item, index) => (
        <TextInput
          key={index}
          placeholder={`Bahan ${index + 1}`}
          style={styles.input}
          value={item}
          onChangeText={(text) => {
            const updated = [...ingredients];
            updated[index] = text;
            setIngredients(updated);
          }}
        />
      ))}
      <TouchableOpacity onPress={handleAddIngredient} style={styles.addButton}>
        <Text style={styles.addButtonText}>+ Tambah Bahan</Text>
      </TouchableOpacity>

      <Text style={styles.sectionTitle}>Langkah Memasak</Text>
      {steps.map((item, index) => (
        <TextInput
          key={index}
          placeholder={`Langkah ${index + 1}`}
          style={styles.input}
          value={item}
          onChangeText={(text) => {
            const updated = [...steps];
            updated[index] = text;
            setSteps(updated);
          }}
        />
      ))}
      <TouchableOpacity onPress={handleAddStep} style={styles.addButton}>
        <Text style={styles.addButtonText}>+ Tambah Langkah</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={pickImage} style={styles.imagePicker}>
        <Text style={styles.imagePickerText}>
          {imageUri ? 'Ganti Gambar' : 'Pilih Gambar'}
        </Text>
      </TouchableOpacity>
      {imageUri && <Image source={{ uri: imageUri }} style={styles.previewImage} />}

      <TouchableOpacity
        onPress={handleSubmit}
        style={[styles.submitButton, uploading && { opacity: 0.6 }]}
        disabled={uploading}
      >
        <Text style={styles.submitButtonText}>
          {uploading ? 'Mengirim...' : 'Simpan Resep'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 20 },
  title: { fontSize: 24, fontWeight: 'bold', marginBottom: 20 },
  input: {
    borderWidth: 1, borderColor: '#ccc', borderRadius: 6,
    padding: 10, marginBottom: 10,
  },
  sectionTitle: {
    fontSize: 18, fontWeight: 'bold', marginTop: 20, marginBottom: 10,
    color: '#f57c00',
  },
  addButton: {
    backgroundColor: '#eee', padding: 10, borderRadius: 6, alignItems: 'center', marginBottom: 10,
  },
  addButtonText: { color: '#555' },
  imagePicker: {
    backgroundColor: '#f0f0f0', padding: 12, borderRadius: 6, alignItems: 'center', marginTop: 15,
  },
  imagePickerText: { fontWeight: 'bold', color: '#333' },
  previewImage: { width: '100%', height: 200, marginTop: 10, borderRadius: 6 },
  submitButton: {
    backgroundColor: '#f57c00', padding: 14, borderRadius: 8, marginTop: 25,
    alignItems: 'center',
  },
  submitButtonText: { color: '#fff', fontSize: 16, fontWeight: 'bold' },
});

export default RecipeDetailScreen;

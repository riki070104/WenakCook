// src/screens/RecipeForm.jsx
import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  Image,
} from "react-native";
import { launchImageLibrary } from 'react-native-image-picker';
import { addNewRecipeAPI } from '../services/API';

const RecipeForm = ({ navigation }) => {
  const [recipeName, setRecipeName] = useState("");
  const [shortDescription, setShortDescription] = useState("");
  const [currentIngredient, setCurrentIngredient] = useState("");
  const [ingredientsList, setIngredientsList] = useState([]);
  const [currentStep, setCurrentStep] = useState("");
  const [stepsList, setStepsList] = useState([]);
  const [imageUri, setImageUri] = useState(null);

  const handleChoosePhoto = () => {
    const options = {
      mediaType: 'photo',
      quality: 0.7,
      maxWidth: 800,
      maxHeight: 800,
    };

    launchImageLibrary(options, (response) => {
      if (response.didCancel) {
        console.log('Pengguna batal memilih gambar');
      } else if (response.errorCode) {
        console.log('ImagePicker Error: ', response.errorMessage);
        Alert.alert('Error Pilih Gambar', `Tidak bisa memilih gambar: ${response.errorMessage}. Pastikan izin sudah diberikan.`);
      } else if (response.assets && response.assets.length > 0) {
        setImageUri(response.assets[0].uri);
        console.log('Gambar dipilih:', response.assets[0].uri);
      }
    });
  };

  const handleAddIngredient = () => {
    if (currentIngredient.trim() !== "") {
      setIngredientsList([...ingredientsList, currentIngredient.trim()]);
      setCurrentIngredient("");
    }
  };

  const handleAddStep = () => {
    if (currentStep.trim() !== "") {
      setStepsList([...stepsList, currentStep.trim()]);
      setCurrentStep("");
    }
  };

  const handleSubmit = async () => {
    if (recipeName.trim() === "") {
      Alert.alert("Input Kurang", "Nama resep gak boleh kosong ya, Bang.");
      return;
    }
    if (ingredientsList.length === 0) {
      Alert.alert("Input Kurang", "Bahan-bahannya minimal satu dong, Bang.");
      return;
    }
    if (stepsList.length === 0) {
      Alert.alert("Input Kurang", "Langkah masaknya juga minimal satu ya.");
      return;
    }
    if (!imageUri) {
      Alert.alert("Input Kurang", "Jangan lupa pilih foto resepnya, Bang.");
      return;
    }

    const newRecipeData = {
      name: recipeName.trim(),
      shortDescription: shortDescription.trim(),
      image: imageUri,
      ingredients: ingredientsList,
      steps: stepsList,
    };

    try {
      await addNewRecipeAPI(newRecipeData);
      Alert.alert("Sukses", "Resep berhasil ditambahkan!");
      navigation.goBack();
    } catch (error) {
      Alert.alert("Gagal", "Gagal menambahkan resep. Coba lagi, Bang!");
      console.error("Error submit resep:", error);
    }
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === "ios" ? "padding" : "height"}
      keyboardVerticalOffset={Platform.OS === "ios" ? 64 : 0}
    >
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={styles.container}
        keyboardShouldPersistTaps="handled"
      >
        <View style={styles.headerNav}>
          <TouchableOpacity style={styles.backButton} onPress={() => navigation.goBack()}>
            <Text style={styles.backButtonText}>← Kembali</Text>
          </TouchableOpacity>
          <Text style={styles.title}>Tambah Resep Baru</Text>
        </View>

        <Text style={styles.label}>Nama Resep:</Text>
        <TextInput
          style={styles.input}
          placeholder="Contoh: Ayam Geprek Sambal Bawang"
          value={recipeName}
          onChangeText={setRecipeName}
        />

        <Text style={styles.label}>Foto Resep:</Text>
        <TouchableOpacity style={styles.imagePickerButton} onPress={handleChoosePhoto}>
          <Text style={styles.imagePickerButtonText}>
            {imageUri ? "Ganti Gambar" : "Pilih Gambar dari Galeri"}
          </Text>
        </TouchableOpacity>
        {imageUri && (
          <View style={styles.imagePreviewContainer}>
            <Image source={{ uri: imageUri }} style={styles.imagePreview} />
            <TouchableOpacity style={styles.removeImageButton} onPress={() => setImageUri(null)}>
              <Text style={styles.removeImageButtonText}>✕ Hapus Gambar</Text>
            </TouchableOpacity>
          </View>
        )}

        <Text style={styles.label}>Deskripsi Singkat (Opsional):</Text>
        <TextInput
          style={[styles.input, styles.multilineInput]}
          placeholder="Contoh: Ayam geprek pedas dengan sambal bawang mantap."
          value={shortDescription}
          onChangeText={setShortDescription}
          multiline
          numberOfLines={3}
        />

        <Text style={styles.label}>Bahan-bahan:</Text>
        {ingredientsList.map((ing, index) => (
          <View key={`ing-${index}`} style={styles.listItemContainer}>
            <Text style={styles.listItem}>• {ing}</Text>
          </View>
        ))}
        <View style={styles.addInputContainer}>
          <TextInput
            style={styles.inputInline}
            placeholder="Ketik satu bahan, lalu Tambah"
            value={currentIngredient}
            onChangeText={setCurrentIngredient}
            onSubmitEditing={handleAddIngredient}
            returnKeyType="done"
          />
          <TouchableOpacity style={styles.addButton} onPress={handleAddIngredient}>
            <Text style={styles.addButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        <Text style={styles.label}>Langkah-langkah Memasak:</Text>
        {stepsList.map((step, index) => (
          <View key={`step-${index}`} style={styles.listItemContainer}>
            <Text style={styles.listItem}>{index + 1}. {step}</Text>
          </View>
        ))}
        <View style={styles.addInputContainer}>
          <TextInput
            style={styles.inputInline}
            placeholder="Ketik satu langkah, lalu Tambah"
            value={currentStep}
            onChangeText={setCurrentStep}
            onSubmitEditing={handleAddStep}
            returnKeyType="done"
          />
          <TouchableOpacity style={styles.addButton} onPress={handleAddStep}>
            <Text style={styles.addButtonText}>+</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <Text style={styles.submitButtonText}>Simpan Resep</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  scrollView: {
    flex: 1,
    backgroundColor: "#fff",
  },
  container: {
    padding: 20,
    paddingBottom: 50,
  },
  headerNav: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  backButton: {
    backgroundColor: "#e0e0e0",
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 8,
    marginRight: 15,
  },
  backButtonText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#333",
  },
  title: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
  },
  label: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginTop: 20,
    marginBottom: 8,
  },
  input: {
    borderColor: "#d0d0d0",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
    marginBottom: 15,
    backgroundColor: '#fdfdfd',
  },
  multilineInput: {
    minHeight: 80,
    textAlignVertical: "top",
  },
  addInputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  inputInline: {
    flex: 1,
    borderColor: "#d0d0d0",
    borderWidth: 1,
    borderRadius: 8,
    paddingHorizontal: 15,
    paddingVertical: 12,
    fontSize: 16,
    marginRight: 10,
    backgroundColor: '#fdfdfd',
  },
  addButton: {
    backgroundColor: '#6a8caf',
    paddingHorizontal: 18,
    paddingVertical: 12,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    height: 50,
  },
  addButtonText: {
    color: '#fff',
    fontSize: 24,
    fontWeight: 'bold',
  },
  listItemContainer: {
    backgroundColor: '#f0f0f0',
    paddingVertical: 10,
    paddingHorizontal: 15,
    borderRadius: 6,
    marginBottom: 7,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  listItem: {
    fontSize: 16,
    color: '#333',
    flex: 1,
  },
  imagePickerButton: {
    backgroundColor: '#6a8caf',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 10,
  },
  imagePickerButtonText: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  imagePreviewContainer: {
    alignItems: 'center',
    marginBottom: 15,
  },
  imagePreview: {
    width: '100%',
    height: 220,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#ddd',
    marginBottom: 8,
    backgroundColor: '#e9e9e9',
  },
  removeImageButton: {
    backgroundColor: '#ff6b6b',
    paddingVertical: 8,
    paddingHorizontal: 15,
    borderRadius: 20,
    position: 'absolute',
    top: 10,
    right: 10,
  },
  removeImageButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },
  submitButton: {
    backgroundColor: '#4CAF50',
    paddingVertical: 15,
    borderRadius: 10,
    alignItems: 'center',
    marginTop: 30,
  },
  submitButtonText: {
    fontSize: 18,
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default RecipeForm;
